from flask import Flask, request, jsonify, render_template, session, send_from_directory
from flask_cors import CORS
from functools import wraps
import os
import json
import uuid
from datetime import datetime
from werkzeug.utils import secure_filename
from config import *
from md_parser import parse_md_to_json, validate_md_format

app = Flask(__name__)
app.secret_key = SECRET_KEY
CORS(app, supports_credentials=True)

# 确保数据文件存在
def init_data_files():
    """初始化数据文件"""
    # 用户文件
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(USERS, f, ensure_ascii=False, indent=2)

init_data_files()

# 登录验证装饰器
def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'username' not in session:
                return jsonify({'success': False, 'message': '请先登录'}), 401
            if role and session.get('role') != role:
                return jsonify({'success': False, 'message': '权限不足'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ============ 页面路由 ============

@app.route('/')
def index():
    """首页 - 登录页面"""
    return render_template('login.html')

@app.route('/student')
def student_page():
    """学生端页面"""
    if 'username' not in session or session.get('role') != 'student':
        return render_template('login.html')
    return render_template('student/dashboard.html')

@app.route('/parent')
def parent_page():
    """家长端页面"""
    if 'username' not in session or session.get('role') != 'parent':
        return render_template('login.html')
    return render_template('parent/dashboard.html')

@app.route('/exam/<question_id>')
def exam_page(question_id):
    """考试页面"""
    if 'username' not in session:
        return render_template('login.html')
    return render_template('student/exam.html', question_id=question_id)

# ============ API路由 ============

@app.route('/api/login', methods=['POST'])
def login():
    """用户登录"""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    
    # 加载用户数据
    with open(USERS_FILE, 'r', encoding='utf-8') as f:
        users = json.load(f)
    
    if username in users and users[username]['password'] == password:
        session['username'] = username
        session['role'] = users[username]['role']
        session['name'] = users[username]['name']
        return jsonify({
            'success': True,
            'role': users[username]['role'],
            'name': users[username]['name']
        })
    
    return jsonify({'success': False, 'message': '用户名或密码错误'}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    """退出登录"""
    session.clear()
    return jsonify({'success': True})

@app.route('/api/user/info')
def get_user_info():
    """获取当前用户信息"""
    if 'username' in session:
        return jsonify({
            'success': True,
            'username': session['username'],
            'role': session.get('role'),
            'name': session.get('name')
        })
    return jsonify({'success': False, 'message': '未登录'}), 401

# ============ 题目相关API ============

@app.route('/api/questions', methods=['GET'])
@login_required()
def get_questions():
    """获取所有题目列表"""
    questions = []
    
    for filename in os.listdir(QUESTIONS_DIR):
        if filename.endswith('.json'):
            question_id = filename[:-5]
            filepath = os.path.join(QUESTIONS_DIR, filename)
            
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 获取进度信息
            progress_file = os.path.join(PROGRESS_DIR, f"{session['username']}_{question_id}.json")
            progress_data = {}
            if os.path.exists(progress_file):
                with open(progress_file, 'r', encoding='utf-8') as f:
                    progress_data = json.load(f)
            
            # 计算进度
            total = len(data.get('questions', []))
            answered = len(progress_data.get('answers', {}))
            progress_percent = int((answered / total * 100)) if total > 0 else 0
            
            questions.append({
                'id': question_id,
                'title': data.get('title', '未命名题单'),
                'createDate': data.get('createDate', ''),
                'totalQuestions': total,
                'answeredCount': answered,
                'progress': progress_percent,
                'lastScore': progress_data.get('lastScore', None),
                'completeDate': progress_data.get('completeDate', None),
                'status': progress_data.get('status', 'not_started')  # not_started, in_progress, completed, stopped
            })
    
    # 按创建日期排序
    questions.sort(key=lambda x: x['createDate'], reverse=True)
    
    return jsonify({'success': True, 'questions': questions})

@app.route('/api/questions/<question_id>', methods=['GET'])
@login_required()
def get_question_detail(question_id):
    """获取题目详情"""
    filepath = os.path.join(QUESTIONS_DIR, f"{question_id}.json")
    
    if not os.path.exists(filepath):
        return jsonify({'success': False, 'message': '题目不存在'}), 404
    
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 获取进度
    progress_file = os.path.join(PROGRESS_DIR, f"{session['username']}_{question_id}.json")
    if os.path.exists(progress_file):
        with open(progress_file, 'r', encoding='utf-8') as f:
            progress_data = json.load(f)
        data['progress'] = progress_data
    
    return jsonify({'success': True, 'data': data})

@app.route('/api/questions/<question_id>/submit', methods=['POST'])
@login_required('student')
def submit_answer(question_id):
    """提交答案"""
    data = request.get_json()
    answers = data.get('answers', {})
    
    # 加载题目
    filepath = os.path.join(QUESTIONS_DIR, f"{question_id}.json")
    if not os.path.exists(filepath):
        return jsonify({'success': False, 'message': '题目不存在'}), 404
    
    with open(filepath, 'r', encoding='utf-8') as f:
        question_data = json.load(f)
    
    # 计算得分
    correct_count = 0
    questions = question_data.get('questions', [])
    
    for idx, q in enumerate(questions):
        user_answer = answers.get(str(idx))
        if user_answer and user_answer == q.get('answer'):
            correct_count += 1
    
    score = correct_count * 10  # 每题10分
    
    # 保存进度
    progress_file = os.path.join(PROGRESS_DIR, f"{session['username']}_{question_id}.json")
    progress_data = {
        'answers': answers,
        'correctCount': correct_count,
        'totalCount': len(questions),
        'lastScore': score,
        'lastSubmitTime': datetime.now().isoformat(),
        'status': 'completed' if len(answers) == len(questions) else 'in_progress'
    }
    
    if len(answers) == len(questions):
        progress_data['completeDate'] = datetime.now().isoformat()
    
    with open(progress_file, 'w', encoding='utf-8') as f:
        json.dump(progress_data, f, ensure_ascii=False, indent=2)
    
    return jsonify({
        'success': True,
        'score': score,
        'correctCount': correct_count,
        'totalCount': len(questions)
    })

# ============ 家长端API ============

@app.route('/api/parent/upload', methods=['POST'])
@login_required('parent')
def upload_md():
    """上传MD文件"""
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': '没有上传文件'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': '文件名为空'}), 400
    
    if not file.filename.endswith('.md'):
        return jsonify({'success': False, 'message': '请上传.md格式的文件'}), 400
    
    # 保存上传的文件
    filename = secure_filename(file.filename)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    saved_filename = f"{timestamp}_{filename}"
    filepath = os.path.join(UPLOAD_DIR, saved_filename)
    file.save(filepath)
    
    # 读取并验证文件内容
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            md_content = f.read()
        
        # 验证格式
        is_valid, message = validate_md_format(md_content)
        if not is_valid:
            return jsonify({'success': False, 'message': message}), 400
        
        # 解析为JSON
        question_data = parse_md_to_json(md_content)
        question_data['createDate'] = datetime.now().isoformat()
        question_data['sourceFile'] = saved_filename
        
        # 生成唯一ID
        question_id = f"quiz_{timestamp}"
        
        # 保存JSON文件
        json_filepath = os.path.join(QUESTIONS_DIR, f"{question_id}.json")
        with open(json_filepath, 'w', encoding='utf-8') as f:
            json.dump(question_data, f, ensure_ascii=False, indent=2)
        
        return jsonify({
            'success': True,
            'message': '上传成功',
            'questionId': question_id,
            'title': question_data.get('title', '未命名'),
            'questionCount': len(question_data.get('questions', []))
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'解析失败: {str(e)}'}), 500

@app.route('/api/parent/questions/<question_id>', methods=['DELETE'])
@login_required('parent')
def delete_question(question_id):
    """删除题目"""
    filepath = os.path.join(QUESTIONS_DIR, f"{question_id}.json")
    
    if not os.path.exists(filepath):
        return jsonify({'success': False, 'message': '题目不存在'}), 404
    
    os.remove(filepath)
    
    # 同时删除所有相关进度文件
    for filename in os.listdir(PROGRESS_DIR):
        if filename.endswith(f"_{question_id}.json"):
            os.remove(os.path.join(PROGRESS_DIR, filename))
    
    return jsonify({'success': True, 'message': '删除成功'})

@app.route('/api/parent/questions/<question_id>/stop', methods=['POST'])
@login_required('parent')
def stop_question(question_id):
    """停止作答"""
    # 获取所有学生的进度文件并设置为stopped
    for filename in os.listdir(PROGRESS_DIR):
        if filename.endswith(f"_{question_id}.json"):
            filepath = os.path.join(PROGRESS_DIR, filename)
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            data['status'] = 'stopped'
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
    
    return jsonify({'success': True, 'message': '已停止作答'})

@app.route('/api/parent/progress/<question_id>', methods=['GET'])
@login_required('parent')
def get_all_progress(question_id):
    """获取所有学生的完成情况"""
    progress_list = []
    
    for filename in os.listdir(PROGRESS_DIR):
        if filename.endswith(f"_{question_id}.json"):
            # 提取用户名
            username = filename.replace(f"_{question_id}.json", "")
            
            filepath = os.path.join(PROGRESS_DIR, filename)
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            progress_list.append({
                'username': username,
                'lastScore': data.get('lastScore', 0),
                'correctCount': data.get('correctCount', 0),
                'totalCount': data.get('totalCount', 0),
                'completeDate': data.get('completeDate'),
                'status': data.get('status', 'not_started')
            })
    
    return jsonify({'success': True, 'progress': progress_list})

# 静态文件服务
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
