"""
Markdown题库解析器
将固定格式的.md文档解析为JSON格式
"""

import re
import json

def validate_md_format(content):
    """
    验证.md文件格式是否正确
    返回: (is_valid: bool, message: str)
    """
    required_sections = ['题目', '答案', '解题过程', '本题考点', '复习要点']
    
    # 检查基本结构
    if not content.strip():
        return False, "文件内容为空"
    
    # 检查是否有标题
    title_match = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
    if not title_match:
        return False, "缺少文档标题（应以#开头）"
    
    # 检查是否有考点标记
    if '### 考点' not in content and '## 考点' not in content:
        return False, "未找到考点标记（应包含'### 考点'或'## 考点'）"
    
    # 检查题目数量
    question_count = len(re.findall(r'(?:^###\s+考点|\*\*题目：\*\*|\*\*题目:\*\*)', content, re.MULTILINE))
    if question_count == 0:
        return False, "未找到任何题目"
    
    # 检查每个题目是否包含必要字段
    # 简单检查：看是否有答案标记
    answer_count = len(re.findall(r'\*\*答案[:：]', content))
    if answer_count == 0:
        return False, "未找到答案标记（应包含'**答案：**'）"
    
    return True, "格式验证通过"

def parse_md_to_json(content):
    """
    解析.md内容转换为JSON格式
    """
    result = {
        'title': '',
        'description': '',
        'questions': []
    }
    
    # 提取标题
    title_match = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
    if title_match:
        result['title'] = title_match.group(1).strip()
    
    # 提取说明部分（标题和第一个考点之间的内容）
    desc_match = re.search(r'^#.+?\n(.+?)(?=\n##?\s+一、|\n###\s+考点|\Z)', content, re.DOTALL | re.MULTILINE)
    if desc_match:
        desc = desc_match.group(1).strip()
        # 移除markdown标记
        desc = re.sub(r'\*\*', '', desc)
        result['description'] = desc
    
    # 按考点分割题目
    # 匹配考点标记：### 考点 X.X 标题
    question_blocks = re.split(r'\n(?=###\s+考点\s+\d+\.?\d*\s+)', content)
    
    for block in question_blocks:
        if not block.strip() or '### 考点' not in block:
            continue
        
        question = parse_question_block(block)
        if question:
            result['questions'].append(question)
    
    return result

def parse_question_block(block):
    """
    解析单个题目块
    """
    question = {
        'id': '',
        'title': '',
        'question': '',
        'options': {},
        'answer': '',
        'solution': '',
        'point': '',
        'review': ''
    }
    
    # 提取考点ID和标题
    # 格式: ### 考点 1.1 标识符、关键字...
    header_match = re.search(r'###\s+考点\s+(\d+\.?\d*)\s+(.+?)(?=\n|$)', block)
    if header_match:
        question['id'] = header_match.group(1)
        question['title'] = header_match.group(2).strip()
    
    # 提取题目内容
    # 匹配 **题目：** 或 **题目:** 后的内容到选项之前
    question_match = re.search(
        r'(?:\*\*题目[:：]\*\*|题目[:：])\s*(.+?)(?=\n\s*[A-D]\.\s|\n\s*A\.|\n\s*\*\*答案|\Z)',
        block, re.DOTALL
    )
    if question_match:
        question_text = question_match.group(1).strip()
        # 清理markdown标记但保留代码块
        question_text = clean_markdown(question_text)
        question['question'] = question_text
    
    # 提取选项
    # 支持格式: A. xxx 或 A．xxx 或 A、xxx 或 A xxx
    option_pattern = r'([A-D])[\.．、\s]\s*(.+?)(?=\n\s*[A-D][\.．、\s]|\n\s*\*\*答案|\Z)'
    options = re.findall(option_pattern, block, re.DOTALL)
    
    for opt_letter, opt_text in options:
        opt_text = opt_text.strip()
        opt_text = clean_markdown(opt_text)
        question['options'][opt_letter] = opt_text
    
    # 提取答案
    answer_match = re.search(r'\*\*答案[:：]\*\*\s*([A-D])', block)
    if answer_match:
        question['answer'] = answer_match.group(1)
    
    # 提取解题过程
    solution_match = re.search(
        r'\*\*解题过程[:：]\*\*\s*([\s\S]*?)(?=\n\s*\*\*本题考点|\Z)',
        block
    )
    if solution_match:
        solution = solution_match.group(1).strip()
        question['solution'] = clean_markdown(solution)
    
    # 提取本题考点
    point_match = re.search(
        r'\*\*本题考点[:：]\*\*\s*([\s\S]*?)(?=\n\s*\*\*复习要点|\Z)',
        block
    )
    if point_match:
        question['point'] = clean_markdown(point_match.group(1).strip())
    
    # 提取复习要点
    review_match = re.search(
        r'\*\*复习要点[:：]\*\*\s*([\s\S]*?)(?=\n---|\Z)',
        block
    )
    if review_match:
        review = review_match.group(1).strip()
        question['review'] = clean_markdown(review)
    
    return question if question['question'] else None

def clean_markdown(text):
    """
    清理markdown标记，但保留代码块格式
    """
    # 移除加粗标记
    text = re.sub(r'\*\*', '', text)
    # 移除斜体标记
    text = re.sub(r'\*([^*]+)\*', r'\1', text)
    # 移除details标签
    text = re.sub(r'<details>.*?</details>', '', text, flags=re.DOTALL)
    text = re.sub(r'<summary>.*?</summary>', '', text, flags=re.DOTALL)
    # 清理多余的空行
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()

def extract_code_blocks(text):
    """
    提取代码块并保留格式
    """
    code_blocks = {}
    counter = 0
    
    def replace_code_block(match):
        nonlocal counter
        placeholder = f"__CODE_BLOCK_{counter}__"
        code_blocks[placeholder] = match.group(0)
        counter += 1
        return placeholder
    
    # 替换代码块
    text = re.sub(r'```[\s\S]*?```', replace_code_block, text)
    
    return text, code_blocks

def restore_code_blocks(text, code_blocks):
    """
    恢复代码块
    """
    for placeholder, code in code_blocks.items():
        text = text.replace(placeholder, code)
    return text

# 测试代码
if __name__ == '__main__':
    # 读取测试文件
    import sys
    if len(sys.argv) > 1:
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 验证格式
        is_valid, message = validate_md_format(content)
        print(f"验证结果: {message}")
        
        if is_valid:
            # 解析
            result = parse_md_to_json(content)
            print(f"\n解析成功！")
            print(f"标题: {result['title']}")
            print(f"题目数量: {len(result['questions'])}")
            
            # 保存为JSON
            output_file = sys.argv[1].replace('.md', '.json')
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"已保存到: {output_file}")
